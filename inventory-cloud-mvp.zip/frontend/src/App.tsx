import { useEffect, useState } from 'react'

const API = (import.meta as any).env.VITE_API_URL || 'http://localhost:8000'
type Product = { id:number; sku:string; name:string; unit:string; default_cost:string; default_price:string; min_stock:string }
type InventoryRow = { product_id:number; sku:string; name:string; unit:string; quantity:string; min_stock:string; estimated_value:string; low_stock:boolean }
type Dashboard = { product_count:number; documents_count:number; low_stock_count:number; estimated_inventory_value:string; receivable:string; payable:string }

function money(value:string|number) {
  return new Intl.NumberFormat('vi-VN',{style:'currency',currency:'VND',maximumFractionDigits:0}).format(Number(value||0))
}

export default function App() {
  const [tab,setTab] = useState('Tổng quan')
  const [dashboard,setDashboard] = useState<Dashboard|null>(null)
  const [products,setProducts] = useState<Product[]>([])
  const [inventory,setInventory] = useState<InventoryRow[]>([])
  const [debts,setDebts] = useState<any[]>([])
  const [documents,setDocuments] = useState<any[]>([])
  const [error,setError] = useState('')
  const [sku,setSku] = useState('')
  const [name,setName] = useState('')
  const [unit,setUnit] = useState('cái')
  const [cost,setCost] = useState('0')
  const [price,setPrice] = useState('0')
  const [minStock,setMinStock] = useState('0')

  async function request(path:string, options?:RequestInit) {
    const response = await fetch(`${API}${path}`,options)
    if (!response.ok) {
      let message = `Lỗi HTTP ${response.status}`
      try { const data = await response.json(); message = data.detail || message } catch {}
      throw new Error(message)
    }
    return response
  }

  async function refresh() {
    setError('')
    try {
      const [d,p,i,de,docs] = await Promise.all([
        request('/api/dashboard').then(r=>r.json()),
        request('/api/products').then(r=>r.json()),
        request('/api/inventory').then(r=>r.json()),
        request('/api/debts').then(r=>r.json()),
        request('/api/documents').then(r=>r.json())
      ])
      setDashboard(d); setProducts(p); setInventory(i); setDebts(de); setDocuments(docs)
    } catch(e:any) { setError(e.message || 'Không kết nối được API') }
  }
  useEffect(()=>{ refresh() },[])

  async function addProduct(e:React.FormEvent) {
    e.preventDefault()
    try {
      await request('/api/products',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({sku,name,unit,default_cost:Number(cost),default_price:Number(price),min_stock:Number(minStock)})})
      setSku(''); setName(''); setCost('0'); setPrice('0'); setMinStock('0')
      await refresh()
      setTab('Hàng hóa')
    } catch(e:any) { setError(e.message) }
  }

  async function exportFile(kind:'inventory'|'debts') {
    try {
      const response = await request(`/api/reports/${kind}.xlsx`)
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a'); a.href=url
      a.download = kind === 'inventory' ? 'bao_cao_ton_kho.xlsx' : 'bao_cao_cong_no.xlsx'
      a.click(); URL.revokeObjectURL(url)
    } catch(e:any) { setError(e.message) }
  }

  const nav = ['Tổng quan','Hàng hóa','Tồn kho','Phiếu nhập/xuất','Công nợ','Báo cáo']
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-icon">K</span><div><strong>Kho của tôi</strong><small>INVENTORY CLOUD</small></div></div>
      <nav>{nav.map(n=><button key={n} className={tab===n?'nav active':'nav'} onClick={()=>setTab(n)}>{n}</button>)}</nav>
      <div className="side-foot">Phiên bản MVP · 0.1</div>
    </aside>
    <main className="main">
      <header className="topbar"><div><span className="eyebrow">QUẢN LÝ KHO HÀNG</span><h1>{tab}</h1></div><button className="secondary" onClick={refresh}>↻ Làm mới</button></header>
      {error && <div className="error">{error}. Kiểm tra backend và cấu hình VITE_API_URL.</div>}
      {tab==='Tổng quan' && <section>
        <div className="cards">
          <Metric title="Mặt hàng" value={dashboard?.product_count ?? '—'} detail="Sản phẩm đang hoạt động"/>
          <Metric title="Phiếu đã ghi nhận" value={dashboard?.documents_count ?? '—'} detail="Tổng phiếu nhập và xuất"/>
          <Metric title="Hàng sắp hết" value={dashboard?.low_stock_count ?? '—'} detail="Theo ngưỡng tồn tối thiểu"/>
          <Metric title="Giá trị tồn ước tính" value={dashboard?money(dashboard.estimated_inventory_value):'—'} detail="Theo giá nhập mặc định"/>
          <Metric title="Công nợ phải thu" value={dashboard?money(dashboard.receivable):'—'} detail="Từ các phiếu xuất còn nợ"/>
          <Metric title="Công nợ phải trả" value={dashboard?money(dashboard.payable):'—'} detail="Từ các phiếu nhập còn nợ"/>
        </div>
        <div className="panel"><h2>Bắt đầu sử dụng</h2><p>Thêm danh mục hàng hóa trước, sau đó tạo phiếu nhập để tăng tồn. Khi xuất hàng, hệ thống kiểm tra số lượng tồn hiện có.</p><button onClick={()=>setTab('Hàng hóa')}>+ Thêm mặt hàng</button></div>
      </section>}
      {tab==='Hàng hóa' && <section className="two-col">
        <div className="panel"><h2>Thêm mặt hàng</h2><form onSubmit={addProduct} className="form">
          <label>Mã hàng<input required value={sku} onChange={e=>setSku(e.target.value)} placeholder="VD: SP001"/></label>
          <label>Tên hàng<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Tên sản phẩm"/></label>
          <div className="form-row"><label>Đơn vị<input value={unit} onChange={e=>setUnit(e.target.value)}/></label><label>Tồn tối thiểu<input type="number" min="0" step="0.001" value={minStock} onChange={e=>setMinStock(e.target.value)}/></label></div>
          <div className="form-row"><label>Giá nhập mặc định<input type="number" min="0" value={cost} onChange={e=>setCost(e.target.value)}/></label><label>Giá bán mặc định<input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)}/></label></div>
          <button type="submit">Lưu mặt hàng</button>
        </form></div>
        <div className="panel"><h2>Danh mục ({products.length})</h2><div className="table-wrap"><table><thead><tr><th>Mã</th><th>Tên hàng</th><th>Đơn vị</th></tr></thead><tbody>{products.map(p=><tr key={p.id}><td>{p.sku}</td><td>{p.name}</td><td>{p.unit}</td></tr>)}</tbody></table></div></div>
      </section>}
      {tab==='Tồn kho' && <section className="panel"><div className="panel-head"><h2>Hiện trạng tồn kho</h2><button className="secondary" onClick={()=>exportFile('inventory')}>Xuất Excel</button></div><DataTable headers={['Mã hàng','Tên hàng','Đơn vị','Tồn','Ngưỡng tối thiểu','Giá trị ước tính']} rows={inventory.map(x=>[x.sku,x.name,x.unit,x.quantity,x.min_stock,money(x.estimated_value)])} warning={inventory.map(x=>x.low_stock)}/></section>}
      {tab==='Phiếu nhập/xuất' && <section className="panel"><div className="panel-head"><h2>Lịch sử phiếu</h2><span className="hint">Tạo phiếu nhập/xuất có thể dùng API /docs ở phiên bản khởi đầu</span></div><DataTable headers={['Mã phiếu','Loại','Ngày','Đối tác','Tổng tiền','Đã thanh toán','Còn nợ']} rows={documents.map(x=>[x.code,x.doc_type==='IN'?'Nhập':'Xuất',x.doc_date,x.party_name||'—',money(x.total),money(x.paid),money(x.outstanding)])}/></section>}
      {tab==='Công nợ' && <section className="panel"><div className="panel-head"><h2>Các khoản còn nợ</h2><button className="secondary" onClick={()=>exportFile('debts')}>Xuất Excel</button></div><DataTable headers={['Mã phiếu','Đối tác','Loại nợ','Ngày','Hạn trả','Tổng tiền','Đã trả','Còn nợ']} rows={debts.map(x=>[x.code,x.party_name,x.debt_kind,x.doc_date,x.due_date||'—',money(x.total),money(x.paid),money(x.outstanding)])}/></section>}
      {tab==='Báo cáo' && <section className="panel"><h2>Xuất báo cáo Excel</h2><p className="muted">Tải báo cáo theo dữ liệu hiện có trên máy chủ.</p><div className="report-actions"><button onClick={()=>exportFile('inventory')}>⇩ Báo cáo tồn kho (.xlsx)</button><button onClick={()=>exportFile('debts')}>⇩ Báo cáo công nợ (.xlsx)</button></div></section>}
      <footer>Inventory Cloud MVP <span>·</span> Dữ liệu lưu trên backend, không lưu riêng trong trình duyệt.</footer>
    </main>
  </div>
}

function Metric({title,value,detail}:{title:string;value:string|number;detail:string}) {
  return <div className="metric"><div className="metric-title">{title}</div><div className="metric-value">{value}</div><div className="metric-detail">{detail}</div></div>
}
function DataTable({headers,rows,warning}:{headers:string[];rows:(string|number)[][];warning?:boolean[]}) {
  if(!rows.length) return <div className="empty">Chưa có dữ liệu. Hãy thêm dữ liệu hoặc tạo phiếu qua API.</div>
  return <div className="table-wrap"><table><thead><tr>{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((row,i)=><tr key={i} className={warning?.[i]?'row-warning':''}>{row.map((cell,j)=><td key={j}>{cell}</td>)}</tr>)}</tbody></table></div>
}
