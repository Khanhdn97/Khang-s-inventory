from __future__ import annotations

import os
from datetime import date, datetime, timezone
from decimal import Decimal
from io import BytesIO
from typing import Literal

from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import (
    create_engine, String, Integer, Date, DateTime, ForeignKey, Numeric,
    Text, select, func
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session, sessionmaker
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./inventory.db")
SECRET_KEY = os.getenv("SECRET_KEY", "local-development-only-change-me")
CORS_ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()]

engine_kwargs = {"pool_pre_ping": True}
if DATABASE_URL.startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sku: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    unit: Mapped[str] = mapped_column(String(40), default="cái")
    default_cost: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0)
    default_price: Mapped[Decimal] = mapped_column(Numeric(14, 2), default=0)
    min_stock: Mapped[Decimal] = mapped_column(Numeric(14, 3), default=0)
    active: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Party(Base):
    __tablename__ = "parties"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    kind: Mapped[str] = mapped_column(String(20))  # customer, supplier, both
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    address: Mapped[str | None] = mapped_column(String(300), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)

class StockDocument(Base):
    __tablename__ = "stock_documents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    doc_type: Mapped[str] = mapped_column(String(10))  # IN / OUT
    party_id: Mapped[int | None] = mapped_column(ForeignKey("parties.id"), nullable=True)
    doc_date: Mapped[date] = mapped_column(Date, default=date.today)
    status: Mapped[str] = mapped_column(String(20), default="posted")
    payment_due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    party: Mapped[Party | None] = relationship()
    items: Mapped[list["StockDocumentItem"]] = relationship(
        back_populates="document", cascade="all, delete-orphan"
    )

class StockDocumentItem(Base):
    __tablename__ = "stock_document_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("stock_documents.id"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    quantity: Mapped[Decimal] = mapped_column(Numeric(14, 3))
    unit_price: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    document: Mapped[StockDocument] = relationship(back_populates="items")
    product: Mapped[Product] = relationship()

class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("stock_documents.id"), index=True)
    paid_at: Mapped[date] = mapped_column(Date, default=date.today)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    method: Mapped[str] = mapped_column(String(30), default="cash")
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    document: Mapped[StockDocument] = relationship()

class StockMovement(Base):
    __tablename__ = "stock_movements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    document_id: Mapped[int] = mapped_column(ForeignKey("stock_documents.id"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), index=True)
    quantity_delta: Mapped[Decimal] = mapped_column(Numeric(14, 3))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Inventory Cloud MVP API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class ProductCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    unit: str = "cái"
    default_cost: Decimal = Field(default=Decimal("0"), ge=0)
    default_price: Decimal = Field(default=Decimal("0"), ge=0)
    min_stock: Decimal = Field(default=Decimal("0"), ge=0)

class ProductOut(ProductCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    active: int

class PartyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    kind: Literal["customer", "supplier", "both"] = "both"
    phone: str | None = None
    address: str | None = None
    note: str | None = None

class PartyOut(PartyCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int

class ItemIn(BaseModel):
    product_id: int
    quantity: Decimal = Field(gt=0)
    unit_price: Decimal = Field(ge=0)

class DocumentCreate(BaseModel):
    doc_type: Literal["IN", "OUT"]
    party_id: int | None = None
    doc_date: date = Field(default_factory=date.today)
    payment_due_date: date | None = None
    note: str | None = None
    items: list[ItemIn] = Field(min_length=1)

class PaymentCreate(BaseModel):
    amount: Decimal = Field(gt=0)
    paid_at: date = Field(default_factory=date.today)
    method: str = "cash"
    note: str | None = None

def document_total(db: Session, document_id: int) -> Decimal:
    rows = db.execute(
        select(StockDocumentItem.quantity, StockDocumentItem.unit_price)
        .where(StockDocumentItem.document_id == document_id)
    ).all()
    return sum((Decimal(q) * Decimal(p) for q, p in rows), Decimal("0"))

def paid_total(db: Session, document_id: int) -> Decimal:
    value = db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.document_id == document_id))
    return Decimal(str(value or 0))

def stock_balance(db: Session, product_id: int) -> Decimal:
    value = db.scalar(select(func.coalesce(func.sum(StockMovement.quantity_delta), 0))
                      .where(StockMovement.product_id == product_id))
    return Decimal(str(value or 0))

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/api/products", response_model=list[ProductOut])
def list_products(q: str = Query(default=""), db: Session = Depends(get_db)):
    stmt = select(Product).where(Product.active == 1).order_by(Product.name)
    if q:
        stmt = stmt.where((Product.name.ilike(f"%{q}%")) | (Product.sku.ilike(f"%{q}%")))
    return list(db.scalars(stmt).all())

@app.post("/api/products", response_model=ProductOut, status_code=201)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    existing = db.scalar(select(Product).where(Product.sku == payload.sku))
    if existing:
        raise HTTPException(409, "Mã sản phẩm đã tồn tại")
    product = Product(**payload.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

@app.get("/api/parties", response_model=list[PartyOut])
def list_parties(q: str = Query(default=""), db: Session = Depends(get_db)):
    stmt = select(Party).order_by(Party.name)
    if q:
        stmt = stmt.where(Party.name.ilike(f"%{q}%"))
    return list(db.scalars(stmt).all())

@app.post("/api/parties", response_model=PartyOut, status_code=201)
def create_party(payload: PartyCreate, db: Session = Depends(get_db)):
    party = Party(**payload.model_dump())
    db.add(party)
    db.commit()
    db.refresh(party)
    return party

@app.post("/api/documents", status_code=201)
def create_document(payload: DocumentCreate, db: Session = Depends(get_db)):
    # Validate all rows before writing anything.
    products: dict[int, Product] = {}
    for item in payload.items:
        product = db.get(Product, item.product_id)
        if not product or not product.active:
            raise HTTPException(404, f"Không tìm thấy sản phẩm ID {item.product_id}")
        products[item.product_id] = product

    if payload.doc_type == "OUT":
        requested: dict[int, Decimal] = {}
        for item in payload.items:
            requested[item.product_id] = requested.get(item.product_id, Decimal("0")) + item.quantity
        for product_id, qty in requested.items():
            current = stock_balance(db, product_id)
            if current < qty:
                raise HTTPException(400, f"Không đủ tồn kho cho {products[product_id].name}; tồn hiện tại: {current}")

    try:
        doc = StockDocument(
            code=f"{payload.doc_type}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
            doc_type=payload.doc_type,
            party_id=payload.party_id,
            doc_date=payload.doc_date,
            payment_due_date=payload.payment_due_date,
            note=payload.note,
            status="posted",
        )
        db.add(doc)
        db.flush()
        for item in payload.items:
            db.add(StockDocumentItem(
                document_id=doc.id, product_id=item.product_id,
                quantity=item.quantity, unit_price=item.unit_price
            ))
            delta = item.quantity if payload.doc_type == "IN" else -item.quantity
            db.add(StockMovement(document_id=doc.id, product_id=item.product_id, quantity_delta=delta))
        db.commit()
        db.refresh(doc)
        return {
            "id": doc.id, "code": doc.code, "doc_type": doc.doc_type,
            "doc_date": str(doc.doc_date), "status": doc.status,
            "total": str(document_total(db, doc.id))
        }
    except Exception:
        db.rollback()
        raise

@app.get("/api/documents")
def list_documents(db: Session = Depends(get_db), limit: int = Query(default=100, ge=1, le=500)):
    docs = db.scalars(select(StockDocument).order_by(StockDocument.id.desc()).limit(limit)).all()
    result = []
    for doc in docs:
        total = document_total(db, doc.id)
        paid = paid_total(db, doc.id)
        result.append({
            "id": doc.id, "code": doc.code, "doc_type": doc.doc_type,
            "party_id": doc.party_id, "party_name": doc.party.name if doc.party else None,
            "doc_date": str(doc.doc_date), "status": doc.status, "total": str(total),
            "paid": str(paid), "outstanding": str(total - paid)
        })
    return result

@app.post("/api/documents/{document_id}/payments", status_code=201)
def add_payment(document_id: int, payload: PaymentCreate, db: Session = Depends(get_db)):
    doc = db.get(StockDocument, document_id)
    if not doc or doc.status != "posted":
        raise HTTPException(404, "Không tìm thấy phiếu đã xác nhận")
    total = document_total(db, document_id)
    already_paid = paid_total(db, document_id)
    if already_paid + payload.amount > total:
        raise HTTPException(400, "Số tiền thanh toán vượt số còn phải trả/thu")
    payment = Payment(document_id=document_id, **payload.model_dump())
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return {"id": payment.id, "document_id": document_id, "paid": str(paid_total(db, document_id)),
            "outstanding": str(total - paid_total(db, document_id))}

@app.get("/api/inventory")
def inventory(db: Session = Depends(get_db)):
    products = db.scalars(select(Product).where(Product.active == 1).order_by(Product.name)).all()
    rows = []
    for product in products:
        qty = stock_balance(db, product.id)
        rows.append({
            "product_id": product.id, "sku": product.sku, "name": product.name,
            "unit": product.unit, "quantity": str(qty), "min_stock": str(product.min_stock),
            "estimated_value": str(qty * Decimal(product.default_cost)),
            "low_stock": qty <= Decimal(product.min_stock)
        })
    return rows

@app.get("/api/debts")
def debts(db: Session = Depends(get_db)):
    docs = db.scalars(select(StockDocument).where(StockDocument.status == "posted")
                      .order_by(StockDocument.doc_date.desc())).all()
    rows = []
    for doc in docs:
        total = document_total(db, doc.id)
        paid = paid_total(db, doc.id)
        outstanding = total - paid
        if outstanding > 0:
            rows.append({
                "document_id": doc.id, "code": doc.code, "doc_type": doc.doc_type,
                "party_name": doc.party.name if doc.party else "Không có đối tác",
                "doc_date": str(doc.doc_date), "due_date": str(doc.payment_due_date) if doc.payment_due_date else None,
                "total": str(total), "paid": str(paid), "outstanding": str(outstanding),
                "debt_kind": "phải trả nhà cung cấp" if doc.doc_type == "IN" else "phải thu khách hàng"
            })
    return rows

@app.get("/api/reports/inventory.xlsx")
def export_inventory(db: Session = Depends(get_db)):
    rows = inventory(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "Ton kho"
    ws.append(["Mã hàng", "Tên hàng", "Đơn vị", "Tồn kho", "Tồn tối thiểu", "Giá trị ước tính"])
    for row in rows:
        ws.append([row["sku"], row["name"], row["unit"], float(row["quantity"]),
                   float(row["min_stock"]), float(row["estimated_value"])])
    style_sheet(ws)
    return workbook_response(wb, "bao_cao_ton_kho.xlsx")

@app.get("/api/reports/debts.xlsx")
def export_debts(db: Session = Depends(get_db)):
    rows = debts(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "Cong no"
    ws.append(["Mã phiếu", "Loại", "Đối tác", "Ngày phiếu", "Hạn thanh toán", "Tổng tiền", "Đã thanh toán", "Còn nợ"])
    for row in rows:
        ws.append([row["code"], row["debt_kind"], row["party_name"], row["doc_date"], row["due_date"],
                   float(row["total"]), float(row["paid"]), float(row["outstanding"])])
    style_sheet(ws)
    return workbook_response(wb, "bao_cao_cong_no.xlsx")

def style_sheet(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="234A6F")
    for col in ws.columns:
        max_len = max((len(str(c.value or "")) for c in col), default=10)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(max_len + 2, 12), 36)

def workbook_response(wb: Workbook, filename: str):
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    product_count = db.scalar(select(func.count(Product.id)).where(Product.active == 1)) or 0
    inv = inventory(db)
    doc_count = db.scalar(select(func.count(StockDocument.id)).where(StockDocument.status == "posted")) or 0
    debt_rows = debts(db)
    receivable = sum((Decimal(x["outstanding"]) for x in debt_rows if x["doc_type"] == "OUT"), Decimal("0"))
    payable = sum((Decimal(x["outstanding"]) for x in debt_rows if x["doc_type"] == "IN"), Decimal("0"))
    return {
        "product_count": product_count,
        "documents_count": doc_count,
        "low_stock_count": sum(1 for x in inv if x["low_stock"]),
        "estimated_inventory_value": str(sum((Decimal(x["estimated_value"]) for x in inv), Decimal("0"))),
        "receivable": str(receivable),
        "payable": str(payable),
    }
